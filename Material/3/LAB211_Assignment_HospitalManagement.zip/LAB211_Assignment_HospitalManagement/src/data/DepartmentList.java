/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.util.HashMap;

/**
 *
 * @author trantuandat
 */
public class DepartmentList extends HashMap<String, Department> {

    public DepartmentList() {
        super();
    }
    
}
