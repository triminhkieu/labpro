/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import tools.Inputter;

/**
 *
 * @author trantuandat
 */
public class DoctorList extends HashMap<String, Doctor> {
    
    public DoctorList() {
        super();
    }
    
    
    
   
    
}
