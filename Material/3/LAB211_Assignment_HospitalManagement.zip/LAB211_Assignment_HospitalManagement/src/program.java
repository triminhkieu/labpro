/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

import tools.*;
import data.*;
import java.util.ArrayList;

/**
 *
 * @author trantuandat
 */
public class program {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws Exception {
        // TODO code application logic here
        String Doc_DataFname = "Doctor_Data.txt";
        String Dept_DataFname = "Department_Data.txt";
        ArrayList<String> mainMenu = new ArrayList();
        mainMenu.add("1. Show information.");
        mainMenu.add("2. Add new.");
        mainMenu.add("3. Update information.");
        mainMenu.add("4. Delete.");
        mainMenu.add("5. Search information.");
        mainMenu.add("6. Load data from file.");
        mainMenu.add("7. Store data to file.");

        ArrayList<String> subMenushow = new ArrayList();
        subMenushow.add("1. Show doctor list");
        subMenushow.add("2. Show department list");

        ArrayList<String> subMenuAdd = new ArrayList();
        subMenuAdd.add("1. Add new doctor.");
        subMenuAdd.add("2. Add new department.");

        ArrayList<String> subMenuUpdate = new ArrayList();
        subMenuUpdate.add("1. Update doctor.");
        subMenuUpdate.add("2. Update Department.");

        ArrayList<String> subMenuDel = new ArrayList();
        subMenuDel.add("1. Delete doctor.");
        subMenuDel.add("2. Delete department.");

        ArrayList<String> subMenuSearch = new ArrayList();
        subMenuSearch.add("1. Search doctor by name.");
        subMenuSearch.add("2. Seach department by ID.");

        ArrayList<String> subMenuLoad = new ArrayList();
        subMenuLoad.add("1. Load doctors data.");
        subMenuLoad.add("2. Load department data.");
        
        ArrayList<String> subMenuSave = new ArrayList();
        subMenuSave.add("1. Save doctors data.");
        subMenuSave.add("2. Save department data.");
        DoctorList docList = new DoctorList();
        DepartmentList departmentList = new DepartmentList();
        Menu menu = new Menu();
        
        HospitalManager manager = new HospitalManager(departmentList, docList);

        int intChoice;
        do {
            System.out.println("----------------------------");
            intChoice = menu.getIntChoice(mainMenu);
            System.out.println("Your choice: " + intChoice);
            switch (intChoice) {
                case 1: {
                    int getSubChoice = menu.getIntChoice(subMenushow);
                    System.out.println("Your choice: " + getSubChoice);
                    switch (getSubChoice) {
                        case 1:
                            manager.printAllDoctorList();
                            break;
                        case 2:
                            manager.printAllDepartmentList();
                            break;
                    }
                    break;
                }
                case 2: {
                    int getSubChoice = menu.getIntChoice(subMenuAdd);
                    System.out.println("Your choice: " + getSubChoice);
                    switch (getSubChoice) {
                        case 1:
                            manager.addNewDoctor();
                            break;
                        case 2:
                            manager.addNewDepartment();
                            break;
                    }
                    break;
                }
                case 3: {
                    int getSubChoice = menu.getIntChoice(subMenuUpdate);
                    System.out.println("Your choice: " + getSubChoice);
                    switch (getSubChoice) {
                        case 1:
                            manager.updateDoctor();
                            break;
                        case 2:
                            manager.updateDepartment();
                            break;
                    }
                    break;
                }
                case 4: {
                    int getSubChoice = menu.getIntChoice(subMenuDel);
                    System.out.println("Your choice: " + getSubChoice);
                    switch (getSubChoice) {
                        case 1:
                            manager.removeDoctor();
                            break;
                        case 2:
                            manager.removeDepartment();
                            break;
                    }
                    break;
                }
                case 5: {
                    int getSubChoice = menu.getIntChoice(subMenuSearch);
                    System.out.println("Your choice: " + getSubChoice);
                    switch (getSubChoice) {
                        case 1:
                            manager.searchDoctorByName();
                            break;
                        case 2:
                            manager.searchDepartmentByID();
                            break;
                    }
                    break;
                }
                case 6: {
                    int getSubChoice = menu.getIntChoice(subMenuLoad);
                    System.out.println("Your choice: " + getSubChoice);
                    switch (getSubChoice) {
                        case 1:
                            manager.loadFromFileDoc_Data(Doc_DataFname);
                            manager.printAllDoctorList();
                            break;
                        case 2:
                            manager.loadFromFileDept_Data(Dept_DataFname);
                            manager.printAllDepartmentList();
                            break;
                    }
                    break;
                }
                case 7: {
                    int getSubChoice = menu.getIntChoice(subMenuSave);
                    System.out.println("Your choice: " + getSubChoice);
                    switch (getSubChoice) {
                        case 1:
                            manager.SaveToDocFile(Doc_DataFname);
                            break;
                        case 2:
                            manager.SaveToDeptFile(Doc_DataFname);
                            break;
                    }
                    break;
                }
            }

        } while (intChoice > 0 && intChoice < 8);

    }
}
